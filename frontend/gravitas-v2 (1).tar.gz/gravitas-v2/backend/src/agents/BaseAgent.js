const { GoogleGenerativeAI } = require('@google/generative-ai');
const logger = require('../utils/logger');
require('dotenv').config();

class BaseAgent {
  constructor(name, systemPrompt) {
    this.name = name;
    this.systemPrompt = systemPrompt;
    if (!process.env.GEMINI_API_KEY) {
      logger.warn(`[${name}] GEMINI_API_KEY not set — AI features disabled`);
      this.disabled = true;
      return;
    }
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    this.model = genAI.getGenerativeModel({
      model: 'gemini-2.0-flash',
      generationConfig: { temperature: 0.4, maxOutputTokens: 2048 },
    });
  }

  async prompt(userPrompt, context = {}) {
    if (this.disabled) return { error: 'Gemini API key not configured' };
    const ctx = Object.keys(context).length ? `\nCONTEXT: ${JSON.stringify(context)}` : '';
    const full = `${this.systemPrompt}${ctx}\n\n${userPrompt}\n\nRespond ONLY with valid JSON. No markdown, no backticks.`;
    try {
      const result = await this.model.generateContent(full);
      const text = result.response.text().trim();
      return this._parse(text);
    } catch (err) {
      logger.error(`[${this.name}] ${err.message}`);
      throw err;
    }
  }

  async chat(history, message) {
    if (this.disabled) return "Gemini API key not configured. Please add it to your .env file.";
    try {
      const chat = this.model.startChat({
        history: [
          { role: 'user', parts: [{ text: this.systemPrompt }] },
          { role: 'model', parts: [{ text: 'Understood. I am your Gravitas AI wellness coach.' }] },
          ...history.map(m => ({
            role: m.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: m.content }],
          })),
        ],
        generationConfig: { temperature: 0.8, maxOutputTokens: 512 },
      });
      const result = await chat.sendMessage(message);
      return result.response.text().trim();
    } catch (err) {
      logger.error(`[${this.name}] chat error: ${err.message}`);
      throw err;
    }
  }

  _parse(text) {
    try {
      return JSON.parse(text.replace(/```json|```/g, '').trim());
    } catch {
      return { raw: text, parseError: true };
    }
  }
}

module.exports = BaseAgent;
