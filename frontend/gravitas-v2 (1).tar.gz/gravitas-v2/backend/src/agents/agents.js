const BaseAgent = require('./BaseAgent');

// ── Agent 1: Communication ────────────────────────────────────────────────────
class CommunicationAgent extends BaseAgent {
  constructor() {
    super('CommunicationAgent', `You are the Communication Agent for Gravitas AI.
Classify emails, summarize content, extract tasks, score urgency 0-100.
Always return structured JSON only.`);
  }

  async processEmail(email) {
    return this.prompt(`Analyze this email and return JSON:
FROM: ${email.sender}
SUBJECT: ${email.subject}
BODY: ${(email.body || email.snippet || '').slice(0, 2000)}

Return: { "category": "work|personal|spam|low_priority|newsletter", "urgencyScore": 0-100, "summary": "2 sentences", "extractedTasks": [{"title":"","priority":"high|medium|low","dueDate":null}], "requiresReply": true|false, "suggestedAction": "Reply|Archive|Delete|None" }`);
  }

  async triageEmails(emails) {
    const list = emails.slice(0, 20).map((e, i) =>
      `[${i}] FROM: ${e.sender} | SUBJECT: ${e.subject} | SNIPPET: ${(e.snippet||'').slice(0,100)}`
    ).join('\n');
    return this.prompt(`Triage these ${emails.length} emails:\n${list}\n\nReturn: { "triage": [{ "index":0, "category":"work|personal|spam|low_priority|newsletter", "urgencyScore":0-100, "summary":"one sentence", "requiresAction":true }], "stats": {"work":0,"spam":0,"newsletter":0,"low_priority":0} }`);
  }
}

// ── Agent 2: Productivity ─────────────────────────────────────────────────────
class ProductivityAgent extends BaseAgent {
  constructor() {
    super('ProductivityAgent', `You are the Productivity Agent for Gravitas AI.
Analyze workload, prioritize tasks, suggest schedules. Return JSON only.`);
  }

  async prioritizeTasks(tasks) {
    return this.prompt(`Prioritize these tasks using urgency × importance:
${JSON.stringify(tasks.map(t => ({ id: t.id, title: t.title, priority: t.priority, dueDate: t.dueDate })))}

Return: { "prioritized": [{ "id":"", "recommendedPriority":"critical|high|medium|low", "aiScore":0-100, "reasoning":"why" }], "suggestions": ["tip1","tip2"] }`);
  }

  async analyzeCalendar(events, dateRange) {
    return this.prompt(`Analyze calendar for ${dateRange.start} to ${dateRange.end}:
${JSON.stringify(events.slice(0, 30).map(e => ({ title: e.summary, start: e.start?.dateTime || e.start?.date, end: e.end?.dateTime || e.end?.date, attendees: e.attendees?.length || 0 })))}

Return: { "workloadScore": 0-100, "workloadIntensity": "light|moderate|heavy|overwhelming", "totalMeetingHours": 0.0, "focusTimeHours": 0.0, "busiestDay": "", "suggestedFocusBlocks": [{"day":"","startTime":"","endTime":""}], "optimalMeetingWindows": [{"day":"","startTime":"","endTime":"","score":0}], "insights": [""] }`);
  }

  async generateDailyPlan(tasks, events, date) {
    return this.prompt(`Create a daily plan for ${date}.
TASKS: ${JSON.stringify(tasks.slice(0,10).map(t=>({title:t.title,priority:t.priority,dueDate:t.dueDate})))}
EVENTS: ${JSON.stringify(events.slice(0,10).map(e=>({title:e.summary,time:e.start?.dateTime})))}

Return: { "schedule": [{"time":"09:00-10:30","type":"deep_work|meeting|break|admin","title":"","description":""}], "topThreeGoals": ["","",""], "motivationalNote": "", "energyForecast": "high|medium|low" }`);
  }
}

// ── Agent 3: Wellness ─────────────────────────────────────────────────────────
class WellnessAgent extends BaseAgent {
  constructor() {
    super('WellnessAgent', `You are the Wellness Coach for Gravitas AI.
You are warm, evidence-based, and specific. Help users avoid burnout, manage energy, and stay productive.
Reference their actual data when available. Give concrete, actionable advice.
When chatting, keep responses under 100 words — concise and direct.`);
  }

  async analyzeWellness(data) {
    return this.prompt(`Analyze this workload data for burnout risk:
${JSON.stringify(data)}

Return: { "burnoutRisk": "low|medium|high", "burnoutScore": 0-100, "wellnessScore": 0-100, "workloadScore": 0-100, "energyPattern": "consistent|declining|volatile|recovering", "immediateActions": [{"action":"","duration":"","reason":"","impact":"high|medium|low"}], "riskFactors": [""], "protectiveFactors": [""], "workPatternInsights": "2-3 sentences", "trend": "improving|stable|declining" }`);
  }

  async suggestBreaks(state) {
    return this.prompt(`User has worked ${state.workingMinutes} minutes. Time: ${state.currentTime}. Meetings today: ${state.meetingHours}h.
Return: { "breakNeeded": true|false, "urgency": "immediate|soon|later", "suggestions": [{"type":"micro|short","duration":"","activity":"","benefit":""}], "motivationalMessage": "" }`);
  }
}

module.exports = {
  communicationAgent: new CommunicationAgent(),
  productivityAgent:  new ProductivityAgent(),
  wellnessAgent:      new WellnessAgent(),
};
